# es_loader_stopper

This is a part of SIEM on Amazon OpenSearch Service. see `https://github.com/aws-samples/siem-on-amazon-opensearch-service`
